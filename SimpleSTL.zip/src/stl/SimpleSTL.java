package stl;

/**
 *
 * @author Ginanjar Fahrul M. <ginanjar.fahrul.m@gmail.com>
 * @version 1.0
 * @since   2013-11-20
 * 
 */
public class SimpleSTL {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //see unit test
    }
}
